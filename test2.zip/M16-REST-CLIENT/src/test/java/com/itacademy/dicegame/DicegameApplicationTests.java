package com.itacademy.dicegame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DicegameApplicationTests {

	@Test
	void contextLoads() {
	}

}
